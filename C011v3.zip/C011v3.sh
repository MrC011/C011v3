clear
echo "\033[34;1mSelamat Datang di Tool Mr.C011"
sleep 1
echo "\033[35;1mAnda disini dapat menginstall berbagai tools" | lolcat
sleep 1
echo "\033[36;1mTetapi tool ini masih beta jadinya masih akan dikembangin lagi" | lolcat
sleep 1
echo "\033[31;1m:) Semoga Bermanfaat (:"
sleep 1
clear
echo $red
cd module
cat asw.txt
echo ""
echo "\033[34;1m[+]\033[36;1m============================\033[34;1m[+]"
echo "\033[32;1m|Author : Mr.C011 &   Mr.HYP3R404"
echo "\033[35;1m|version Tools: 2"
echo "\033[35;1m|Team : Mojokerto Noobs Team"
echo "\033[31;1m|Please For Subcribe Youtube:"
echo "\033[92m|DS TUTORIAL" 
echo "\033[34;1m[+]\033[36;1m============================\033[34;1m[+]"
echo ""
echo "\033[32;1mSilahkan Pilih Tools Yang mau Kamu pake..:"
echo "\033[36;1m"
echo "[+]===============================================[+]"
echo $red "01. Spam Sms Tokped" 
echo $green "02. Spam Sms Telkomnyet" 
echo $yellow "03. Nyari Cc Buat Carding" 
echo $blue "04. Install meTAInstall" 
echo $cyan "05. Litespam untuk spam sms" 
echo $gold "06. Hammer untuk ddos website" 
echo $purple "07. Red_Hawk untuk scan website" 
echo $white "08. Install WPScan" 
echo $yellow "09. install sqlscan" 
echo $blue "10. Install sqlmap" 
echo $red "11. Install santet-online buat nyantet orang" 
echo $green "12. Install VbugMaker" 
echo $purple "13. Install Kalinet-hunter" 
echo $cyan "14. Install Metasploit" 
echo $red "15. Install Script deface Creator"
echo $green "16. Install XSStrike" 
echo $purple "17. Install D-TECT" 
echo $yellow "18. Install Nmap" 
echo $pink "19. Install BlackBox" 
echo $gold "20. Install Infoga" 
echo $yellow "21. Install Lazymux" 
echo $green "22. Install Mbf Hack Akun Fb"
echo $red "23. Install V-Create [ Virus Terbaru ]" 
echo $cyan "24. Install Webdav Buat Deface" 
echo $yellow "25. Install Ktp/KK Generate"
echo $green "26. Install Sqlmap Buat Inject Web"
echo $yellow "27. Install LITEDDOS Untuk DDOS Website"
echo $red "28. Install Weeman Buat Phising"
echo $cyan "29. Install A-Rat Buat Meretas Android"
echo $gold "30. Main MOON-BOGY No Root"
echo $yellow "31. Spammer SMS Grab"
echo $pink "32. Install Tools Daijobu"
echo $cyan "33. Dengarkan Musik Di Termux"
echo $purple "34. Browsing Di Termux"
echo $green "35. Install Tools 4wsectools"
echo $gold "36. Spammer Dengan GCOSPAM"
echo $cyan "37. Tools Spam LITESPAM"
echo $yellow "38. Install Tools Ubuntu"
echo $pink "39. Spam Telpon Jd.id"
echo $red "40. Dengerin Lagu Youtube Di Termux"
echo $green "41. Install Devploit Di Termux"
echo $yellow "42. Install Osif"
echo $cyan "43. Install Tools Instagram Private"
echo $pink "44. Install Tools Katoolin"
echo $red "45. Auto Reactions Facebook"
echo $yellow "46. Bom SMS Telkomnyet"
echo $green "47. Install Blazy Untuk Hack Admin Login"
echo $red "48. Install Breacher Untuk Mengetahui Lokasi/Letak Admin Suatu Web"
echo $cyan "49. Install ReconDog"
echo $blue "50. Install Tools Dorking Di Termux"
echo "0. Exit" | lolcat
echo "\033[36;1m"
echo "[+]===============================================[+]"

echo "\033[35;1m Silahkan pilih yang mau anda install"

read -p "#Mr.C011 ~>#" pilihan

if [ $pilihan = "01" ] || [ $pilihan = "1" ]
then
clear
toilet "Mr.C011" 
php 1.php
fi

if [ $pilihan = "02" ] || [ $pilihan = "2" ]
then
clear
toilet "Mr.C011"
pkg install php
php t.php
fi

if [ $pilihan = "03" ] || [ $pilihan = "3" ]
then
clear
toilet "Mr.C011"
php key.php
fi

if [ $pilihan = "04" ] || [ $pilihan = "4" ]
then
clear
toilet -f big -F gay "MR . C011"
pkg update && upgrade
pkg install git
git clone https://github.com/4L13199/meTAInstall
chmod +x meTAInstall
mv meTAInstall $HOME
cd $HOME/meTAInstall
sh meTAInstall
fi

if [ $pilihan = "05" ] || [ $pilihan = "05" ]
then
clear
toilet -f big -F gay "MR . C011"
apt update
apt upgrade
pkg install toilet
pkg install php
pkg install git
git clone� https://github.com/4L13199/LITESPAM
cd LITESPAM
sh LITESPAM.sh
fi

if [ $pilihan = "06" ] || [ $pilihan = "6" ]
then
clear
toilet -f big -F gay "MR . C011"
pkg update
pkg upgrade
pkg install python
pkg install git
git clone https://github.com/cyweb/hammer
cd hammer
python hammer.py
fi 

if [ $pilihan = "07" ] || [ $pilihan = "7" ]
then
clear
toilet -f big -F gay "MR . C011"
apt update && apt upgrade
apt install git 
apt install php
apt install php-curl
apt install php-xml
git clone https://github.com/Tuhinshubhra/RED_HAWK
cd RED_HAWK
php rhawk.php
fi

if [ $pilihan = "08" ] || [ $pilihan = "8" ]
then
clear
toilet -f big -F gay "MR . C011"
apt update && apt upgrade
apt install git
apt install ruby
git clone https://github.com/wpscanteam/wpscan/
cd wpscan
chmod 777 wpscan.rb
gem install bundle
bundle install -j5
ruby wpscan.rb
fi

if [ $pilihan = "09" ] || [ $pilihan = "9" ]
then
clear
toilet -f big -F gay "MR . C011"
pkg install php
pkg install git
git clone http://www.github.com/Cvar1984/sqlscan.git
cd sqlscan
chmod +x sqlscan.php
php sqlscan.php
fi

if [ $pilihan = "10" ] || [ $pilihan = "10" ]
then
clear
toilet -f big -F gay "MR . C011"
apt update
apt upgrade
apt install python
apt install python2
apt install git
git clone https://github.com/sqlmapproject/sqlmap.git
cd sqlmap
python2 sqlmap.py
fi

if [ $pilihan = "11" ] || [ $pilihan = "11" ]
then 
clear
toilet -f big -F gay "MR . C011"
apt update
apt upgrade
pkg install python2
pkg install git
git clone https://github.com/Gameye98/santet-online
mv santet-online $HOME
cd $HOME/santet-online
python2 santet.py
fi

if [ $pilihan = "12" ] || [ $pilihan = "12" ]
then
clear
toilet -f big -F gay "MR . C011"
apt update && apt upgrade -y
apt install wget
apt install python2
wget -O vbug.zip� https://doc-0s-0o-docs.googleusercontent.com/docs/securesc/ha0ro937gcuc7l7deffksulhg5h7mbp1/e5a7oc1kmqtjj3q840qjo91eihpa81lk/1518789600000/00678403534077713655/*/0BzXPbcyKYA7rUkxHWXdqeVNvMU0?e=download
unzip vbug.zip
cd vbug
python2 vbug.py
fi

if [ $pilihan = "13" ] || [ $pilihan = "13" ]
then
clear
toilet -f big -F gay "MR . C011"
apt update
apt upgrade 
pkg install git
git clone� https://github.com/Hax4us/Nethunter-In-Termux
cd Nethunter-In-Termux
chmod +x kalinethunter
./kalinethunter
fi

if [ $pilihan = "14" ] || [ $pilihan = "14" ]
then
clear
toilet -f big -F gay "MR . C011"
pkg update
pkg upgrade
pkg install wget
wget https://Auxilus.github.io/metasploit.sh
sh metasploit.sh
cd metasploit-framework
./msfconsole
fi

if [ $pilihan = "15" ] || [ $pilihan = "15" ]
then
clear
toilet -f big -F gay "MR . C011"
apt update 
apt upgrade
apt install git
apt install python
apt install python2
git clone https://github.com/Ubaii/script-deface-creator
cd script-deface-creator
python2 create.py
fi

if [ $pilihan = "16" ] || [ $pilihan = "16" ]
then
clear
toilet -f big -F gay "MR . C011"
apt update
apt upgrade
apt install python2
apt install git
git clone https://github.com/UltimateHackers/XSStrike
cd XSStrike
pip2 install -r requirements.txt
python2 xsstrike
fi

if [ $pilihan = "17" ] || [ $pilihan = "17" ]
then
clear
toilet -f big -F gay "MR . C011"
apt update && apt upgrade
pkg install python2 
pkg install git
git clone https://github.com/shawarkhanethicalhacker/D-TECT
cd D-TECT
chmod +x d-tect.py
python2 d-tect.py
fi

if [ $pilihan = "18" ] || [ $pilihan = "18" ]
then
clear
toilet -f big -F gay "MR . C011"
apt update
apt upgrade
apt install nmap
fi

if [ $pilihan = "19" ] || [ $pilihan = "19" ]
then
clear
toilet -f big -F gay "MR . C011"
apt update 
apt upgrade
pkg install python2 wget
wget https://raw.githubusercontent.com/jothatron/blackbox/master/blackbox.py
pip2 install requests pexpect passlib
python2 blackbox.py
fi

if [ $pilihan = "20" ] || [ $pilihan = "20" ]
then
clear
toilet -f big -F gay "MR . C011"
apt update
apt upgrade
pkg install git
pkg install python
pkg install python2
git clone https://github.com/m4ll0k/infoga
cd infoga
python2 infoga.py
fi

if [ $pilihan = "21" ] || [ $pilihan = "21" ]
then
clear
toilet -f big -F gay "MR. C011"
apt update && apt upgrade
apt install git
git clone https://github.com/Gameye98/Lazymux
cd Lazymux
ls
python2 lazymux.py
fi

if [ $pilihan = "22" ] || [ $pilihan = "22" ]
then
clear
toilet -f big -F gay "MR. C011"
apt update && apt upgrade
pkg install python2 git
pip2 install mechanize
git clone https://github.com/pirmansx/mbf
ls
mv mbf $HOME
cd $HOME/mbf
python2 MBF.py
fi

if [ $pilihan = "23" ] || [ $pilihan = "23" ]
then
clear
toilet -f big -F gay "MR. C011"
cd /storage/emulated/0
git clone https://github.com/amruhu/V-create
mv V-create $HOME
cd $HOME/V-create
python2 1.py
fi

if [ $pilihan = "24" ] || [ $pilihan = "24" ]
then
clear
toilet -f big -F gay "MR. C011"
apt update && upgrade
apt install python2
pip2 install urllib3 chardet certifi idna requests
apt install openssl curl
pkg install libcurl
ln -s /sdcard
cd sdcard
mkdir webdav
cd webdav
curl -k -O https://pastebin.com/raw/HnVyQPtR
mv HnVyQPtR webdav.py
python2 webdav.py
cd
cd /sdcard/webdav
python2 webdav.py
fi

if [ $pilihan = "25" ] || [ $pilihan = "25" ]
then
clear
toilet -f big -F gay "MR. C011"
pkg install git
git clone https://github.com/zerosvn/ktpkkgenerate
mv ktpkkgenerate $HOME
cd $HOME/ktpkkgenerate
php zerosvn.php
fi

if [ $pilihan = "26" ] || [ $pilihan = "26" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt update
apt install git
git clone https://github.com/sqlmapproject/sqlmap
mv sqlmap $HOME
cd $HOME/sqlmap
read -p "masukan web target:" target
python2 sqlmap.py -D target
fi

if [ $pilihan = "27" ] || [ $pilihan = "27" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt update
apt install git
git clone htps://github.com/4L13199/LITEDDOS
mv LITEDDOS $HOME
cd $HOME/LITEDDOS
read -p "Masukkan Target:" target
python2 LITEDDOS.py target 80 100
fi

if [ $pilihan = "28" ] || [ $pilihan = "28" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt install git
apt install php
git vlone https://github.com/evait-security/weeman.git
mv weeman $HOME
cd $HOME/weeman
python2 weeman.py
fi

if [ $pilihan = "29" ] || [ $pilihan = "29" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt install git
git clone https://github.com/Xi4u7/A-Rat.git
mv A-Rat $HOME
cd $HOME/A-Rat
python2 A-Rat.py
fi

if [ $pilihan = "30" ] || [ $pilihan = "30" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt update
apt upgrade
pkg install moon-buggy
moon-buggy
fi

if [ $pilihan = "31" ] || [ $pilihan = "31" ]
then
clear
toilet -f standard -F gay "Mr.C011"
pkg install python2
pkg install requests
pkg install git
git clone https://github.com/p4kl0nc4t/Spammer-Grab
mv Spammer-Grab $HOME
cd $HOME/Spammer-Grab
chmod +x spammer.py
python2 spammer.py
fi

if [ $pilihan = "32" ] || [ $pilihan = "32" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt install git
apt install php
git clone https://github.com/alintamvans/diejoubu
mv diejoubu $HOME
cd $HOME/diejoubu
cd v1.2
php diejoubu.php
fi

if [ $pilihan = "33" ] || [ $pilihan = "33" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt update && apt upgrade
apt install wget
mkdir ngrok
cd ~/ngrok
wget https://bin.equinox.io/c/4vmDzA7iaHb/ngrok-stable-linux-arm.zip
mv ngrok-stable-linux-arm.zip $HOME
$HOME/unzip ngrok-stable-linux-arm.zip
cd ~/
ls
fi

if [ $pilihan = "34" ] || [ $pilihan = "34" ]
then
clear
toilet -f standard -F gay "Mr.C011"
pkg install w3m
w3m www.google.com
fi

if [ $pilihan = "35" ] || [ $pilihan = "35" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt update
apt install git
git clone https://github.com/aryanrtm/4wsectools
mv 4wsectools $HOME
cd $HOME/4wsectools
chmod 777 tools
./tools
fi

if [ $pilihan = "36" ] || [ $pilihan = "36" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt upgrade && apt update
apt install git 
git clone https://github.com/Amriez/gcospam
mv gcospam $HOME
cd $HOME/gcospam
sh install.sh
sh gco.sh
fi

if [ $pilihan = "37" ] || [ $pilihan = "37" ]
then
clear
toilet -f standard -F gay "Mr.C011"
pkg install php
pkg install toilet
pkg install sh
pkg install git
git clone https://github.com/4L13199/LITESPAM
mv LITESPAM $HOME
cd $HOME/LITESPAM
sh LITESPAM.sh
fi

if [ $pilihan = "38" ] || [ $pilihan = "38" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt update
apt install git
apt install wget
apt install proot
git clone https://github.com/Neo-Oli/termux-ubu&#8230;
mv termux-ubuntu $HOME
cd $HOME/termux-ubuntu
chmod +x ubuntu.sh
./ubuntu.sh
./start.sh
fi

if [ $pilihan = "39" ] || [ $pilihan = "39" ]
then
clear
toilet -f standard -F gay "Mr.C011"
pkg install php 
pkg install curl
curl https://pastebin.com/raw/9BYy1JVc -o jdid.php
mv jdid.php $HOME
cd $HOME
php jdid.php
fi

if [ $pilihan = "40" ] || [ $pilihan = "40" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt update && apt upgrade
apt install pip
pkg install python
pkg install python2
pip install mps_youtube
pip install youtube_dl
pkg install mpv
mpsyt
fi

if [ $pilihan = "41" ] || [ $pilihan = "41" ]
then
clear
toilet -f standard -F gay "Mr.C011"
pkg update && pkg upgrade
pkg install git
pkg install python2 
git clone https://github.com/joker25000/Devploit
mv Devploit $HOME
cd $HOME/Devploit
python2 Devploit.py
fi

if [ $pilihan = "42" ] || [ $pilihan = "42" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt update && apt upgrade
pkg install git python2
git clone https://github.com/ciku370/OSIF
mv OSIF $HOME
cd $HOME/OSIF
pip2 install -r requirements.txt
python2 osif.py
fi

if [ $pilihan = "43" ] || [ $pilihan = "43" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt update && apt upgrade -y
apt install nodejs git
git clone https://github.com/anadhelf/ig
mv ig $HOME
cd $HOME/ig
npm install 
node fftauto
fi

if [ $pilihan = "44" ] || [ $pilihan = "44" ]
then
clear
pkg install git
pkg install python2
pkg install gnupg
pkg install nano
git clone https://github.com/LionSec/katoolin.git
mv katoolin $HOME
cd $HOME/katoolin
python2 katoolin.py
fi

if [ $pilihan = "45" ] || [ $pilihan = "45" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt update && apt upgrade -y
apt instal git php curl -y
git clone https://github.com/AMVengeance/FB-React.git
mv FB-React $HOME
cd $HOME/FB-React
chmod +x start
./start
fi

if [ $pilihan = "46" ] || [ $pilihan = "46" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt update && apt upgrade
apt install php
git clone https://github.com/dandyraka/TelkBombV2.git
mv TelkBombV2 $HOME
cd $HOME/TelkBombV2
php tsel.php
fi

if [ $pilihan = "47" ] || [ $pilihan = "47" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt install git python2 python2-dev clang libxml2
git clone https://github.com/UltimateHackers/Blazy.git
mv Blazy $HOME
cd $HOME/Blazy
pip2 install -r requirements.txt
python2 blazy.py
fi

if [ $pilihan = "48" ] || [ $pilihan = "48" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt update && apt upgrade
apt install git
apt install python2
git clone https://github.com/UltimateHackers/Breacher.git
mv Breacher $HOME
cd $HOME/Breacher
python2 breacher.py
fi

if [ $pilihan = "49" ] || [ $pilihan = "49" ]
then
clear
toilet -f standard -F gay "Mr.C011"
apt install python2
apt install git
git clone https://github.com/UltimateHackers/ReconDog
mv ReconDog $HOME
cd $HOME/ReconDog
python2 dog.py
fi

if [ $pilihan = "50" ] || [ $pilihan = "50" ]
then
clear
toilet -f standard -F gay "Mr.C011"
pkg install git
pkg install python2
git clone https://github.com/XG77Z10/Google-Dork 
mv Google-Dork $HOME
cd $HOME/Google-Dork
pip2 install termcolor
python2 Google.py
fi

if [ $pilihan = "0" ] || [ $pilihan = "0" ]
then
echo "MOJOKERTO NOOBS TEAM" | lolcat
echo "We Are Anonymous" | lolcat
echo "We Are Legion" | lolcat
echo "We Do Not For Give" | lolcat
echo "We Do Not For Get" | lolcat
echo "EXPECT US" | lolcat
exit
fi